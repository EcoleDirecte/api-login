<?php

/* 
** 
** Se connecte à EcoleDirecte
** 
*/

$cookie_rand = 'ecoledirecte.cookie';
$cookie    = '/tmp/.'.$cookie_rand;

             $postLoginFields= 'data={
    "identifiant": "' . $_GET['id'] . '",
    "motdepasse": "' . $_GET['pwd'] . '"
}';

$url1="https://vm-api.ecoledirecte.com/v3/login.awp";

            $options=array(
                  CURLOPT_URL            => $url1, // Url cible (l'url la page que vous voulez télécharger)
                  CURLOPT_RETURNTRANSFER => true, // Retourner le contenu téléchargé dans une chaine (au lieu de l'afficher directement)
                  CURLOPT_FOLLOWLOCATION => false,
                  CURLOPT_HEADER         => false, // Ne pas inclure l'entête de réponse du serveur dans la chaine retournée
                  CURLOPT_FAILONERROR    => false,       // Gestion des codes d'erreur HTTP supérieurs ou égaux à 400
                  CURLOPT_POST           => true,       // Effectuer une requête de type POST
                  CURLOPT_COOKIEJAR      => $cookie,
                  CURLOPT_COOKIEFILE     => $cookie,
                  CURLOPT_USERAGENT      => 'Mozilla/5.0 (X11; Linux x86_64; rv:47.0) Gecko/20100101 Firefox/47.0)', 
                  CURLOPT_POSTFIELDS     => $postLoginFields // Le tableau associatif contenant les variables envoyées par POST au serveur

            );

            $curl1=curl_init();
             
                  curl_setopt_array($curl1,$options);
             
                  $content1=curl_exec($curl1);
             
            curl_close($curl1);
			echo $content1;
			$token = substr($content1 , 21 , 4024);
			echo "<br /><br />token = " . $token . "<br /><br />";
            $curl1 = null;
 
?>