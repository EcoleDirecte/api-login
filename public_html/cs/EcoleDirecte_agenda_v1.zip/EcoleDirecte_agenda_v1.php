<?php

/* 
** 
** Se connecte à EcoleDirecte
** 
*/

$cookie_rand = 'ecoledirecte.cookie';
$cookie    = '/tmp/.'.$cookie_rand;
$agendaDate = $_GET['date'];

             /* $postLoginFields= 'data={
    "identifiant": "identifiant",
    "motdepasse": "mot de passe"
}'; */

             $postLoginFields= 'data={
    "identifiant": "' . $_GET['id'] . '",
    "motdepasse": "' . $_GET['pwd'] . '"
}';

$url1="https://vm-api.ecoledirecte.com/v3/login.awp";

// while(true) {

            // Tableau contenant les options de téléchargement
            $options=array(
                  CURLOPT_URL            => $url1, // Url cible (l'url la page que vous voulez télécharger)
                  CURLOPT_RETURNTRANSFER => true, // Retourner le contenu téléchargé dans une chaine (au lieu de l'afficher directement)
                  CURLOPT_FOLLOWLOCATION => false,
                  CURLOPT_HEADER         => false, // Ne pas inclure l'entête de réponse du serveur dans la chaine retournée
                  CURLOPT_FAILONERROR    => false,       // Gestion des codes d'erreur HTTP supérieurs ou égaux à 400
                  CURLOPT_POST           => true,       // Effectuer une requête de type POST
                  CURLOPT_COOKIESESSION  => 1,
                  CURLOPT_COOKIEJAR      => $cookie,
                  CURLOPT_COOKIEFILE     => $cookie,
                  CURLOPT_USERAGENT      => 'Mozilla/5.0 (X11; Linux x86_64; rv:47.0) Gecko/20100101 Firefox/47.0)', 
                  CURLOPT_POSTFIELDS     => $postLoginFields // Le tableau associatif contenant les variables envoyées par POST au serveur

            );
			
            $curl1=curl_init();
             
                  // Configuration des options de téléchargement
                  curl_setopt_array($curl1,$options);
				  
                  $content1=curl_exec($curl1);      // Le contenu téléchargé est enregistré dans la variable $content. Libre à vous de l'afficher.
             
			 
            curl_close($curl1);
			echo $content1;
			$token = substr($content1 , 22, 4120);
			$ec_id = strstr($content1 , '"id":');
			$ec_id = substr($ec_id , 5 , 4);
			// $url3 = "https://vm-api.ecoledirecte.com/v3/Eleves/" . $ec_id . "/cahierdetexte/2016-09-19.awp?verbe=get&";
			$url3 = "https://vm-api.ecoledirecte.com/v3/Eleves/" . $ec_id . "/cahierdetexte/" . $agendaDate . ".awp?verbe=get&";
			$token = ltrim($token , "\"abcdefhijklmnopqrstuvwxyzABCDEFHIJKLMNOPQRSTUVWXYZ");
			echo "<br /><br />ec_id = " . $ec_id . "<br /><br />";
			// echo "<br /><br />token = " . $token . "<br /><br />";
            $curl1 = null;
			
             $postAgendaFields= 'data={
    "token": "' . $token . '"
}';
			
			/* --------------------------------------------------------------------------------------------------------------------------------------- */

			echo "<br /><br />";
			
            $options[CURLOPT_URL] = $url3;
            $options[CURLOPT_POSTFIELDS] = $postAgendaFields;
            unset($options[CURLOPT_COOKIESESSION]);
             
            $curl3=curl_init();
             
                  curl_setopt_array($curl3,$options);
                  $content3=curl_exec($curl3);
             
            echo $content3;
			curl_close($curl3);
            
// }

// mysql_close();
 
?>